<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!------ Include the above in your HEAD tag ---------->
    <title>Document</title>

    <Style>
        /* Tabs*/
    /*section {
        padding: 60px 0;
    }

    section .section-title {
        text-align: center;
        color: #007b5e;
        margin-bottom: 50px;
        text-transform: uppercase;
    }
    #tabs{
        background: gray;
        color: #eee;
    }
    #tabs h6.section-title{
        color: #eee;
    }

    #tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
        color: #f3f3f3;
        background-color: transparent;
        border-color: transparent transparent #f3f3f3;
        border-bottom: 4px solid !important;
        font-size: 20px;
        font-weight: bold;
    }
    #tabs .nav-tabs .nav-link {
        border: 1px solid transparent;
        border-top-left-radius: .25rem;
        border-top-right-radius: .25rem;
        color: #eee;
        font-size: 20px;
    }*/
    </Style>

</head>
<body>
    <!-- Tabs -->
<section id="tabs">
	<div class="container">
		<h6 class="section-title h1">Rates</h6>
		<div class="row">
			<div class="col-xs-12 ">
				<nav>
					<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
						<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">FX</a>
						<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">PTA</a>
						<a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Interest Rate</a>
						<!-- <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">About</a> -->
					</div>
				</nav>
				<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
					<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="col-sm-12">
                            <h1 class="display-3" style="margin-left: 450px;">FX</h1>
                            <div class="">
                                <button class="btn btn-primary pull-left" style="margin: 19px; margin-left: 1000px;" data-toggle="modal" data-target="#myModal">Create FX</button>
                            </div>
                            <!-- <div>
                            <a style="margin: 19px; margin-left: 1000px;" href="" class="btn btn-primary">Create FX</a>
                            </div> -->
                          <table class="table table-striped">
                            <thead>
                                <tr>
                                  <td>Country</td>
                                  <td>Currency</td>
                                  <td>Fx Buy</td>
                                  <td>Fx Sell</td>
                                  <td>Status</td>
                                  <td colspan = 2><h5 style="margin-left: 60px;"><b>Actions</b></h5></td>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($contacts as $contact)
                                <tr>
                                    <td>{{$contact->country}}</td>
                                    <td>{{$contact->currency}}</td>
                                    <td>{{number_format($contact->fx_buy, 2)}}</td>
                                    <td>{{number_format($contact->fx_sell, 2)}}</td>
                                    <td>
                                        @if($contact->status == 'enable')
                                            <span class="badge bg-blue">Enable</span>
                                        @else
                                            <span class="badge bg-pink">Disable</span>
                                        @endif
                                    </td>
                                    <!-- <td>
                                      <input data-id="{{$contact->id}}" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Enable" data-off="Disable" {{ $contact->status ? 'checked' : '' }}>
                                    </td> -->

                                    <td>
                                        <a href="#" data-toggle="modal" data-target="#editModal{{ $contact->fx_id }}" class="btn btn-primary">Edit</a>
                                    </td>

                                    
                                    <td>
                                        <form action="{{ route('fx.destroy', $contact->fx_id)}}" method="post">
                                          @csrf
                                          @method('DELETE')
                                          <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>


                                 <div id="editModal{{ $contact->fx_id }}" class="modal fade" role="dialog">
                                            <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <!-- <h2 class="modal-title">Edit FX</h2> -->

                                                </div>
                                                <form action="/fx/{{$contact->fx_id}}" method="post">
                                                    @method("PATCH")
                                                    @csrf

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="country" class="col-form-label">Country:</label>
                                                        <input type="text" name="country" class="form-control" id="country" value="{{ $contact->country }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="currency" class="col-form-label">Currency:</label>
                                                        <input type="text" name="currency" class="form-control" id="currency" value="{{ $contact->currency }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="fx_buy" class="col-form-label">FX Buy:</label>
                                                        <input type="text" name="fx_buy" class="form-control" id="fx_buy" value="{{ $contact->fx_buy }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="fx_sell" class="col-form-label">FX Sell:</label>
                                                        <input type="text" name="fx_sell" class="form-control" id="fx_sell" value="{{ $contact->fx_sell }}">
                                                        </div>
                                                    </div>

                                                    <!-- <div class="control-group"> -->
                                                    <div class="modal-body">
                                                        <label class="control-label">Status</label>
                                                        <div class="controls">
                                                          <input type="checkbox" name="status" id="status" {{ $contact->status == "enable" ? 'checked' : '' }} >
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                            </div>
                                        </div>

                                @endforeach
                            </tbody>
                          </table>

                        </div>
					</div>

                    <!------------------------------------- PTA ------------------------------------->


					<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div class="col-sm-12">
                            <h1 class="display-3" style="margin-left: 450px;">PTA</h1>
                            <div class="">
                                <button class="btn btn-primary pull-left" style="margin: 19px; margin-left: 1000px;" data-toggle="modal" data-target="#ptaModal">Create PTA</button>
                            </div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                  <td>Country</td>
                                  <td>PTA Name</td>
                                  <td>Value</td>
                                  <td>Status</td>
                                  <td colspan = 2><h5 style="margin-left: 70px;"><b>Actions</b></h5></td>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($ptas as $pta)
                                <tr>
                                    <td>{{$pta->country}}</td>
                                    <td>{{$pta->pta_name}}</td>
                                    <td>{{number_format($pta->value, 2)}}</td>
                                    <td>
                                        @if($pta->status == 'enable')
                                            <span class="badge bg-blue">Enable</span>
                                        @else
                                            <span class="badge bg-pink">Disable</span>
                                        @endif
                                    </td>

                                    <td>
                                        <a href="#" data-toggle="modal" data-target="#editptaModal{{ $pta->pta_rate_id }}" class="btn btn-primary">Edit</a>
                                    </td>

                                    <td>
                                        <form action="{{ route('pta-delete', $pta->pta_rate_id)}}" method="POST">
                                          @csrf
                                          @method('DELETE')
                                          <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>

                                <!---------------------------- EDIT PTA  --------------------------->

                                <div id="editptaModal{{ $pta->pta_rate_id }}" class="modal fade" role="dialog">
                                            <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <!-- <h2 class="modal-title">Edit FX</h2> -->

                                                </div>
                                                <form action="/pta-update/{{$pta->pta_rate_id}}" method="post">
                                                    @method("PATCH")
                                                    @csrf

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="country" class="col-form-label">Country:</label>
                                                        <input type="text" name="country" class="form-control" id="country" value="{{ $pta->country }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="pta_name" class="col-form-label">PTA Name:</label>
                                                        <input type="text" name="pta_name" class="form-control" id="pta_name" value="{{ $pta->pta_name }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="value" class="col-form-label">Value:</label>
                                                        <input type="numeric" name="value" class="form-control" id="value" value="{{ $pta->value }}">
                                                        </div>
                                                    </div>

                                                    <!-- <div class="control-group"> -->
                                                    <div class="modal-body">
                                                        <label class="control-label">Status</label>
                                                        <div class="controls">
                                                          <input type="checkbox" name="status" id="status" {{ $pta->status == "enable" ? 'checked' : '' }} >
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                            </div>
                                </div>


                                @endforeach
                            </tbody>
                          </table>
						</div>
					</div>

                    <!-------------------------------------- INTEREST RATE ---------------------------------->


					<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                        <div class="col-sm-12">
                            <h1 class="display-3" style="margin-left: 300px;">INTEREST RATE</h1>
                            <div class="">
                                <button class="btn btn-primary pull-left" style="margin: 19px; margin-left: 1000px;" data-toggle="modal" data-target="#interestRateModal">Create Rate</button>
                            </div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                  <td>Country</td>
                                  <td>Interest Category</td>
                                  <td>Above 5m</td>
                                  <td>Below 5m</td>
                                  <td>Status</td>
                                  <td colspan = 2><h5 style="margin-left: 60px;"><b>Actions</b></h5></td>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($interestRates as $interestRate)
                                <tr>
                                    <td>{{$interestRate->country}}</td>
                                    <td>{{$interestRate->interest_category}}</td>
                                    <td>{{$interestRate->above_5m}}</td>
                                    <td>{{$interestRate->below_5m}}</td>
                                    <td>
                                        @if($interestRate->status == 'enable')
                                            <span class="badge bg-blue">Enable</span>
                                        @else
                                            <span class="badge bg-pink">Disable</span>
                                        @endif
                                    </td>

                                     <td>
                                        <a href="#" data-toggle="modal" data-target="#editInterestRateModal{{ $interestRate->interest_rate_id }}" class="btn btn-primary">Edit</a>
                                    </td>
                                    
                                    <td>
                                        <form action="{{ route('interestRate-delete', $interestRate->interest_rate_id)}}" method="post">
                                          @csrf
                                          @method('DELETE')
                                          <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>

                                <!-------------------------- EDIT INTEREST RATE ------------------------>

                                <div id="editInterestRateModal{{ $interestRate->interest_rate_id }}" class="modal fade" role="dialog">
                                            <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <!-- <h2 class="modal-title">Edit FX</h2> -->

                                                </div>
                                                <form action="/interestRate-update/{{$interestRate->interest_rate_id}}" method="post">
                                                    @method("PATCH")
                                                    @csrf

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="country" class="col-form-label">Country:</label>
                                                        <input type="text" name="country" class="form-control" id="country" value="{{ $interestRate->country }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="interest_category" class="col-form-label">Interest Category:</label>
                                                        <input type="text" name="interest_category" class="form-control" id="interest_category" value="{{ $interestRate->interest_category }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="above_5m" class="col-form-label">Above 5m:</label>
                                                        <input type="numeric" name="above_5m" class="form-control" id="above_5m" value="{{ $interestRate->above_5m }}">
                                                        </div>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                        <label for="below_5m" class="col-form-label">Below 5m:</label>
                                                        <input type="numeric" name="below_5m" class="form-control" id="below_5m" value="{{ $interestRate->below_5m }}">
                                                        </div>
                                                    </div>

                                                    <!-- <div class="control-group"> -->
                                                    <div class="modal-body">
                                                        <label class="control-label">Status</label>
                                                        <div class="controls">
                                                          <input type="checkbox" name="status" id="status" {{ $interestRate->status == "enable" ? 'checked' : '' }} >
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                            </div>
                                </div>

                                @endforeach
                            </tbody>
                        </table>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

    <!------------------------------------ CREATE FORM FOR FX  -------------------------------------->


    <div id="myModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <!-- <h6 class="modal-title">Modal Header</h6> -->
                            </div>
                            <form action="/fx" method="post">
                                @csrf

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="country" class="col-form-label">Country:</label>
                                    <input type="text" name="country" class="form-control" id="country" placeholder="Enter Country">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="currency" class="col-form-label">Currency:</label>
                                    <input type="text" name="currency" class="form-control" id="currency" placeholder="Currency">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="fx_buy" class="col-form-label">FX Buy:</label>
                                    <input type="numeric" name="fx_buy" class="form-control" id="fx_buy" placeholder="FX Buy">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="fx_sell" class="col-form-label">FX Sell:</label>
                                    <input type="numeric" name="fx_sell" class="form-control" id="fx_sell" placeholder="FX Sell">
                                    </div>
                                </div>

                                <div class="modal-body">
                                        <label class="control-label">Status</label>
                                        <div class="controls">
                                          <input type="checkbox" name="status" id="enable" value="enable">
                                        </div>
                                </div>

                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                        </div>
    </div>

    <!------------------------------------ CREATE FORM FOR PTA -------------------------------------->

    <div id="ptaModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <!-- <h6 class="modal-title">Modal Header</h6> -->
                            </div>
                            <form action="/pta-save" method="post">
                                @csrf

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="country" class="col-form-label">Country:</label>
                                    <input type="text" name="country" class="form-control" id="country" placeholder="Enter Country">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="pta_name" class="col-form-label">PTA Name:</label>
                                    <input type="text" name="pta_name" class="form-control" id="pta_name" placeholder="PTA">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="value" class="col-form-label">Value:</label>
                                    <input type="numeric" name="value" class="form-control" id="value" placeholder="Value">
                                    </div>
                                </div>

                                <div class="modal-body">
                                        <label class="control-label">Status</label>
                                        <div class="controls">
                                          <input type="checkbox" name="status" id="enable" value="enable">
                                        </div>
                                </div>

                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                        </div>
    </div>

    <!------------------------------------ CREATE FORM FOR INTEREST RATE -------------------------------------->

    <div id="interestRateModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <!-- <h6 class="modal-title">Modal Header</h6> -->
                            </div>
                            <form action="/interestRate-save" method="post">
                                @csrf

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="country" class="col-form-label">Country:</label>
                                    <input type="text" name="country" class="form-control" id="country" placeholder="Enter Country">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="interest_category" class="col-form-label">Interest Category:</label>
                                    <input type="text" name="interest_category" class="form-control" id="interest_category" placeholder="Interest Category">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="above_5m" class="col-form-label">Above 5m:</label>
                                    <input type="numeric" name="above_5m" class="form-control" id="above_5m" placeholder="Above 5m">
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="form-group">
                                    <label for="below_5m" class="col-form-label">Below 5m:</label>
                                    <input type="numeric" name="below_5m" class="form-control" id="below_5m" placeholder="Below 5m">
                                    </div>
                                </div>

                                <div class="modal-body">
                                        <label class="control-label">Status</label>
                                        <div class="controls">
                                          <input type="checkbox" name="status" id="enable" value="enable">
                                        </div>
                                </div>

                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                        </div>
    </div>

</section>
<!-- ./Tabs -->

</body>
</html>








